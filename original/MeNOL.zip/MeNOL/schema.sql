DROP TABLE IF EXISTS `main`;

CREATE TABLE `main` (
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL DEFAULT '',
  `prevLocation` varchar(255) NOT NULL DEFAULT '',
  `colors` varchar(255) NOT NULL DEFAULT '',
  `items` varchar(1000) NOT NULL,
  `energy` int(11) NOT NULL DEFAULT '0',
  `disks` int(11) NOT NULL DEFAULT '0',
  `widgets` int(11) NOT NULL DEFAULT '0',
  `currentZone` varchar(255) NOT NULL DEFAULT '',
  `akiliniDisks` varchar(255) NOT NULL DEFAULT '',
  `hoverDisk` int(11) NOT NULL DEFAULT '0',
  `anarchist` int(11) NOT NULL DEFAULT '0',
  `idealist` int(11) NOT NULL DEFAULT '0',
  `airship` int(11) NOT NULL DEFAULT '0',
  `akilini` int(11) NOT NULL DEFAULT '0',
  `gamesWon` int(11) NOT NULL DEFAULT '0',
  `temple` int(11) DEFAULT '0',
  `tournament` int(11) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `birthday` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
