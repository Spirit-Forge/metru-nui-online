The root directory contains the index.htm as well as the static .swf files. It also contains a file called "schema.sql" which contains a SQL query that will populate a MySQL database with a table that has the correct fields.

"SFX" contains all of the sound and music for the game.

"XML" contains a bunch of static .xml files that the game uses, as well as four .php scripts. These have been populated with some dummy database names, usernames, and passwords, but when pointing to the right place they return the XML values that the .swf files are expecting. I expect they are highly susceptible to injection attacks, so I wouldn't recommend using them directly, but it may not matter for an offline installation.
