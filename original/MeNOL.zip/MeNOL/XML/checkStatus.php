<?php
session_start();
?>
<?php

echo "\n";
echo "<checkStatus>";

$username = $_GET["username"];

$chandle = mysqli_connect("localhost","menol", "menol","menol")
     or die("Connection Failure to Database</checkStatus>");
  $query1="select * from main where username = '$username'";
  $result = mysqli_query($chandle, $query1) or die("false</checkStatus>");

        $i=0;
  $fieldname = array("end" => 50);
  while ($i < mysqli_num_fields($result))
  {
    $field_name=mysqli_fetch_field_direct($result, $i);
    $fieldname[$i]=$field_name->name;
    $i++;
  }
  $i=0;
      $thisrow=mysqli_fetch_row($result);

      echo "<result>";
      if($thisrow[1] == ""){
        echo "false";
      } else {
         echo "true";
      }
        echo "</result>";



  mysqli_free_result($result);
  mysqli_close($chandle);

?>
</checkStatus>
