<?php
session_start();
?>
<?php
$username = $_GET["username"];
$password= $_GET["password"];
$location = $_GET["location"];
$prevLocation = $_GET["prevLocation"];
$items = $_GET["items"];
$disks = $_GET["disks"];
$energy = $_GET["energy"];
$widgets = $_GET["widgets"];
$currentZone = $_GET["currentZone"];
$akiliniDisks= $_GET["akiliniDisks"];
$hoverDisk= $_GET["hoverDisk"];
$anarchist= $_GET["anarchist"];
$idealist= $_GET["idealist"];
$airship= $_GET["airship"];
$akilini= $_GET["akilini"];
$gamesWon= $_GET["gamesWon"];
$temple= $_GET["temple"];
$tournament = $_GET["tournament"];

echo "<resultset>";

$chandle = mysqli_connect("localhost", "menol","menol","menol")
     or die("Connection Failure to Database</resultset>");

  $query1="select * from main where username = '$username'";
  $result = mysqli_query($chandle, $query1) or die("Failed Query: $query1</playerStatus>");
  $i=0;
  $fieldname = array("end" => 50);
  while ($i < mysqli_num_fields($result))
  {
    $field_name=mysqli_fetch_field_direct($result, $i);
    $fieldname[$i]=$field_name->name;
    $i++;
  }
  $i=0;
  $thisrow=mysqli_fetch_row($result);


    if($thisrow[1] == $password){
  $query1="update main set location = '$location' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

    $query1="update main set prevLocation = '$prevLocation' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

    $query1="update main set items = '$items' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

    $query1="update main set disks = '$disks' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

    $query1="update main set energy = '$energy' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

    $query1="update main set widgets = '$widgets' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

    $query1="update main set currentZone = '$currentZone' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

      $query1="update main set akiliniDisks = '$akiliniDisks' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

      $query1="update main set hoverDisk = '$hoverDisk' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set anarchist = '$anarchist' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

$query1="update main set idealist = '$idealist' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

$query1="update main set airship = '$airship' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set akilini = '$akilini' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

   $query1="update main set gamesWon = '$gamesWon' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

   $query1="update main set temple = '$temple' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

   $query1="update main set tournament = '$tournament' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  } else {
     echo "Don't be a hacker, please!";
  }
  echo "</resultset>";

    mysqli_free_result($result);
  mysqli_close($chandle);
?>
