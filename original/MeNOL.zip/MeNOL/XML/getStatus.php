<?php
session_start();
?>
<?php

echo "\n";
echo "<playerStatus>";

$username = $_GET["username"];
$password = $_GET["password"];

$chandle = mysqli_connect("localhost","menol", "menol", "menol")
     or die("Connection Failure to Database</playerStatus>");
  $query1="select * from main where username = '$username'";
  $result = mysqli_query($chandle, $query1) or die("Failed Query: $query1</playerStatus>");
  $i=0;
  $fieldname = array("end" => 50);
  while ($i < mysqli_num_fields($result))
  {
    $field_name=mysqli_fetch_field_direct($result, $i);
    $fieldname[$i]=$field_name->name;
    $i++;
  }
  $i=0;
      $thisrow=mysqli_fetch_row($result);

      if($thisrow[1] == $password){
      echo "<",$fieldname[2], ">";
      echo $thisrow[2];
      echo "</",$fieldname[2], ">";

      echo "<",$fieldname[3], ">";
      echo $thisrow[3];
      echo "</",$fieldname[3], ">";

       echo "<",$fieldname[4], ">";
      echo $thisrow[4];
      echo "</",$fieldname[4], ">";

       echo "<",$fieldname[5], ">";
      echo $thisrow[5];
      echo "</",$fieldname[5], ">";

       echo "<",$fieldname[6], ">";
      echo $thisrow[6];
      echo "</",$fieldname[6], ">";

       echo "<",$fieldname[7], ">";
      echo $thisrow[7];
      echo "</",$fieldname[7], ">";

       echo "<",$fieldname[0], ">";
      echo $thisrow[0];
      echo "</",$fieldname[0], ">";

       echo "<",$fieldname[1], ">";
      echo $thisrow[1];
      echo "</",$fieldname[1], ">";

       echo "<",$fieldname[8], ">";
      echo $thisrow[8];
      echo "</",$fieldname[8], ">";

       echo "<",$fieldname[9], ">";
      echo $thisrow[9];
      echo "</",$fieldname[9], ">";

      echo "<",$fieldname[10], ">";
      echo $thisrow[10];
      echo "</",$fieldname[10], ">";

      echo "<",$fieldname[11], ">";
      echo $thisrow[11];
      echo "</",$fieldname[11], ">";

      echo "<",$fieldname[12], ">";
      echo $thisrow[12];
      echo "</",$fieldname[12], ">";

      echo "<",$fieldname[13], ">";
      echo $thisrow[13];
      echo "</",$fieldname[13], ">";

      echo "<",$fieldname[14], ">";
      echo $thisrow[14];
      echo "</",$fieldname[14], ">";

      echo "<",$fieldname[15], ">";
      echo $thisrow[15];
      echo "</",$fieldname[15], ">";

      echo "<",$fieldname[16], ">";
      echo $thisrow[16];
      echo "</",$fieldname[16], ">";

        echo "<",$fieldname[17], ">";
      echo $thisrow[17];
      echo "</",$fieldname[17], ">";

        echo "<",$fieldname[18], ">";
      echo $thisrow[18];
      echo "</",$fieldname[18], ">";
      } else {
        echo "Don't be a hacker!";
      }

  mysqli_free_result($result);
  mysqli_close($chandle);

?>
</playerStatus>
