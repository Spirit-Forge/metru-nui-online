
<?php
session_start();
?>
<?php
$username = $_GET["username"];
$password= $_GET["password"];
$colors= $_GET["colors"];
$firstDisk= $_GET["firstDisk"];
$email= $_GET["email"];
$bday= $_GET["bday"];

echo "<resultset>";

$chandle = mysqli_connect("localhost","menol", "menol", "menol")
    or die("Connection Failure to Database</resultset>");
$query1="INSERT INTO main (username) VALUES ('$username')";
mysqli_query($chandle, $query1)
    or die("Failed Query: $query1</resultset>");

    $query1="update main set password= '$password' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set colors= '$colors' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set location= 'chute' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set prevLocation= 'elsewhere' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set currentZone= 'z_moto_hub' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set energy = 100 where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set hoverDisk= 111 where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set akiliniDisks = '$firstDisk' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set widgets  = 30 where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set email  = '$email' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set birthday  = '$bday' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  $query1="update main set items  = '3,3,3,27,27' where username = '$username'";
  mysqli_query($chandle, $query1) or die("Failed Query: $query1</resultset>");

  echo "</resultset>";

  mysqli_close($chandle);

?>
